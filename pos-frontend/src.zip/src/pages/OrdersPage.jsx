import React, { useEffect, useState } from "react";

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      const res = await fetch("http://localhost:5000/api/orders");
      const data = await res.json();
      setOrders(data);
    };
    fetchOrders();
  }, []);

  const formatCurrency = (value) => {
    if (typeof value === "number") {
      return value.toFixed(2);
    }
    const parsed = parseFloat(value);
    return isNaN(parsed) ? "0.00" : parsed.toFixed(2);
  };

  return (
    <div className="flex flex-col p-4 w-full h-full overflow-hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-4">
        <div className="flex gap-3 text-sm font-semibold">
          <button className="text-primary border-b-2 border-primary pb-1">
            Current Order
          </button>
          <button className="text-gray-500 hover:text-primary">Online Order</button>
          <button className="text-gray-500 hover:text-primary">Advance Order</button>
        </div>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 border rounded text-sm">All</button>
          <button className="px-3 py-1.5 border rounded text-sm">Dine In</button>
          <button className="px-3 py-1.5 border rounded text-sm">Delivery</button>
          <button className="px-3 py-1.5 border rounded text-sm">Pick Up</button>
        </div>
        <input
          type="text"
          placeholder="Search"
          className="border px-3 py-1 rounded text-sm w-full md:w-64"
        />
      </div>

      <div className="overflow-auto border rounded-lg">
        <table className="min-w-full table-auto text-sm">
          <thead className="bg-gray-100 text-gray-700 text-xs uppercase">
            <tr>
              <th className="px-2 py-2">Order No</th>
              <th>Order Type</th>
              <th>Table</th>
              <th>People</th>
              <th>Phone</th>
              <th>Name</th>
              <th>Payment</th>
              <th>Amount</th>
              <th>Discount</th>
              <th>Grand Total</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order, index) => (
              <tr key={index} className="bg-green-100 border-t">
                <td className="px-2 py-2 text-center">{order.order_number}</td>
                <td>{order.order_type || "-"}</td>
                <td>{order.table_info || "-"}</td>
                <td>{order.people_count || "-"}</td>
                <td>{order.customer_phone || "-"}</td>
                <td>{order.customer_name || "-"}</td>
                <td>{order.payment_type || "-"}</td>
                <td>{formatCurrency(order.subtotal)}</td>
                <td>({formatCurrency(order.discount)})</td>
                <td>{formatCurrency(order.grand_total)}</td>
                <td>{new Date(order.created_at).toLocaleString()}</td>
                <td className="space-x-2 text-blue-600 underline cursor-pointer">
                  <span>View</span>
                  <span>Reprint</span>
                  <span>Cancel</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrdersPage;
