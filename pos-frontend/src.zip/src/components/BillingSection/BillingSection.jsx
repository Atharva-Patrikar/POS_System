"use client"

import { useEffect, useState } from "react"
import { FaCreditCard, FaMoneyBillWave, FaMobile } from "react-icons/fa"
import OrderTypeToggle from "./OrderTypeToggle"
import SelectedItems from "./SelectedItems"
import DiscountInput from "./DiscountInput"
import TotalSummary from "./TotalSummary"
import ActionButtons from "./ActionButtons"

const BillingSection = ({
  cart,
  setCart,
  totalPrice,
  paymentMethod,
  setPaymentMethod,
  tableNumber,
  peopleCount,
  setPeopleCount,
  customerName,
  setCustomerName,
  customerMobile,
  setCustomerMobile,
  customerAddress,
  setCustomerAddress,
  activeTab,
  setActiveTab,  // Ensure setActiveTab is passed here
}) => {
  const [pdfUrl, setPdfUrl] = useState(null)
  const [showDiscount, setShowDiscount] = useState(false)
  const [discountType, setDiscountType] = useState("percentage")
  const [discountValue, setDiscountValue] = useState(0)
  const [appliedDiscount, setAppliedDiscount] = useState(0)
  const [showPeopleInput, setShowPeopleInput] = useState(false)
  const [showCustomerForm, setShowCustomerForm] = useState(false)

  useEffect(() => {
    if (cart.length === 0) {
      setAppliedDiscount(0)
      setDiscountValue(0)
      setShowDiscount(false)
    }
  }, [cart])

  const updateQuantity = (id, qty) => {
    const newQty = parseInt(qty, 10)
    if (!isNaN(newQty) && newQty > 0) {
      setCart((prevCart) =>
        prevCart.map((item) => (item.id === id ? { ...item, qty: newQty } : item))
      )
    }
  }

  const removeItem = (id) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id))
  }

  const removeFromCart = (id) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => (item.id === id ? { ...item, qty: item.qty - 1 } : item))
        .filter((item) => item.qty > 0)
    )
  }

  const addToCart = (dish) => {
    setCart((prevCart) =>
      prevCart.map((item) => (item.id === dish.id ? { ...item, qty: item.qty + 1 } : item))
    )
  }

  const handleApplyDiscount = () => {
    const value = parseFloat(discountValue || 0)
    const amount = discountType === "percentage" ? (totalPrice * value) / 100 : value
    setAppliedDiscount(amount)
    setShowDiscount(false)
  }

  const handleRemoveDiscount = () => {
    setDiscountValue(0)
    setAppliedDiscount(0)
    setShowDiscount(false)
  }

  const handleSaveCustomer = () => {
    console.log("Customer Info Saved:", {
      name: customerName,
      mobile: customerMobile,
      address: customerAddress,
    })
  }

  const taxAmount = totalPrice * 0.05
  const grandTotal = totalPrice + taxAmount - appliedDiscount

  const customerDetails = {
    name: customerName,
    phone: customerMobile,
    address: customerAddress,
  }

  return (
    <div className="w-2/5 bg-white border-l border-gray-200 shadow-sm flex flex-col">
      {/* Pass setActiveTab to OrderTypeToggle */}
      <OrderTypeToggle
        activeTab={activeTab}
        setActiveTab={setActiveTab} // Pass setActiveTab here
        showCustomerForm={showCustomerForm}
        setShowCustomerForm={setShowCustomerForm}
        customerName={customerName}
        setCustomerName={setCustomerName}
        customerMobile={customerMobile}
        setCustomerMobile={setCustomerMobile}
        customerAddress={customerAddress}
        setCustomerAddress={setCustomerAddress}
        handleSaveCustomer={handleSaveCustomer}
        peopleCount={peopleCount}
        setPeopleCount={setPeopleCount}
        showPeopleInput={showPeopleInput}
        setShowPeopleInput={setShowPeopleInput}
      />

      {/* SelectedItems Component */}
      <SelectedItems
        cart={cart}
        removeFromCart={removeFromCart}
        updateQuantity={updateQuantity}
        addToCart={addToCart}
        removeItem={removeItem}
      />

      <div className="border-t border-gray-200 bg-gray-50 p-4">
        {/* Total Summary and Discount Input */}
        <TotalSummary totalPrice={totalPrice} taxAmount={taxAmount} appliedDiscount={appliedDiscount} />

        <DiscountInput
          showDiscount={showDiscount}
          setShowDiscount={setShowDiscount}
          discountType={discountType}
          setDiscountType={setDiscountType}
          discountValue={discountValue}
          setDiscountValue={setDiscountValue}
          handleApplyDiscount={handleApplyDiscount}
          handleRemoveDiscount={handleRemoveDiscount}
        />

        {/* Payment Method Selection */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
          <div className="grid grid-cols-3 gap-2">
            {[{ label: "Cash", icon: <FaMoneyBillWave /> }, { label: "Card", icon: <FaCreditCard /> }, { label: "UPI", icon: <FaMobile /> }].map((method) => (
              <button
                key={method.label}
                onClick={() => setPaymentMethod(method.label)}
                className={`flex items-center justify-center gap-2 py-2 text-sm rounded-md ${
                  paymentMethod === method.label
                    ? "bg-black text-white"
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
              >
                {method.icon}
                {method.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <ActionButtons
          cart={cart}
          grandTotal={grandTotal}
          paymentMethod={paymentMethod}
          setPdfUrl={setPdfUrl}
          pdfUrl={pdfUrl}
          tableNumber={tableNumber}
          peopleCount={peopleCount}
          customerDetails={customerDetails}
          activeTab={activeTab}
          orderType={activeTab}
        />
      </div>
    </div>
  )
}

export default BillingSection
