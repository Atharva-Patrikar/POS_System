"use client"

import { FaSave, FaPrint, FaFileInvoice, FaPause } from "react-icons/fa"
import generateBillPdf from "../../utils/generateBillPdf"

const ActionButtons = ({ 
  cart, 
  grandTotal, 
  paymentMethod, 
  setPdfUrl, 
  pdfUrl, 
  tableNumber, 
  peopleCount, 
  customerDetails,
  orderType, // ✅ New prop
}) => {
  const handlePrintAndSave = async () => {
    try {
      const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0)
      const tax = 0
      const discount = 0

      const customerData = {
        name: customerDetails?.name || "",
        phone: customerDetails?.phone || "",
        address: customerDetails?.address || "",
      }

      const response = await fetch("http://localhost:5000/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          order_type: orderType, // ✅ Dynamic order type
          table_info: tableNumber,
          people_count: peopleCount,
          customer: customerData,
          payment_type: paymentMethod,
          subtotal,
          tax,
          discount,
          grand_total: grandTotal,
          items: cart,
        }),
      })

      const result = await response.json()
      if (result.success) {
        generateBillPdf(cart, grandTotal, paymentMethod, orderType, setPdfUrl) // ✅ Pass correct order type
      } else {
        alert("Failed to save order.")
      }
    } catch (err) {
      console.error("Error saving order:", err)
      alert("Something went wrong while saving order.")
    }
  }

  return (
    <div className="grid grid-cols-2 gap-1 text-xs">
      <button className="flex items-center justify-center bg-black text-white text-xs py-1 px-2 rounded-md hover:bg-gray-800">
        <FaSave className="mr-2" />
        Save Order
      </button>

      <button
        onClick={handlePrintAndSave}
        className="flex items-center justify-center bg-black text-white text-sm py-2 px-3 rounded-md hover:bg-gray-800"
      >
        <FaPrint className="mr-2" />
        Print Bill
      </button>

      <button className="flex items-center justify-center bg-gray-200 text-gray-800 text-sm py-2 px-3 rounded-md hover:bg-gray-300">
        <FaFileInvoice className="mr-2" />
        Generate eBill
      </button>

      <button className="flex items-center justify-center bg-gray-200 text-gray-800 text-sm py-2 px-3 rounded-md hover:bg-gray-300">
        <FaPause className="mr-2" />
        Hold Order
      </button>

      {pdfUrl && (
        <div className="col-span-2 mt-2">
          <a href={pdfUrl} download="Bill.pdf" className="block">
            <button className="flex items-center justify-center bg-green-600 text-white py-2 px-3 text-sm rounded-md hover:bg-green-700 w-full">
              <FaFileInvoice className="mr-2" />
              Download PDF
            </button>
          </a>
        </div>
      )}
    </div>
  )
}

export default ActionButtons
