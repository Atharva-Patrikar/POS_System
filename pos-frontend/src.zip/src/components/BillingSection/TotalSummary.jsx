const TotalSummary = ({ totalPrice, taxAmount, appliedDiscount }) => {
    return (
      <>
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-gray-600">Subtotal</div>
          <div className="text-sm font-medium">₹{totalPrice}</div>
        </div>
  
        <div className="flex justify-between items-center mb-2">
          <div className="text-sm text-gray-600">Tax (5%)</div>
          <div className="text-sm font-medium">₹{taxAmount.toFixed(2)}</div>
        </div>
  
        {/* 🆕 Discount status below tax */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-gray-600">Discount</div>
          <div className="text-sm font-medium text-red-600">
            -₹{appliedDiscount ? appliedDiscount.toFixed(2) : "0.00"}
          </div>
        </div>
      </>
    )
  }
  
  export default TotalSummary
  