"use client";

import { UserRound, Users, StickyNote, ConciergeBell, FilePenLine, CheckCircle } from "lucide-react";
import { useState } from "react";
import debounce from "lodash.debounce";

const OrderTypeToggle = ({ 
  showCustomerForm, 
  setShowCustomerForm, 
  customerName, 
  setCustomerName, 
  customerMobile,
  setCustomerMobile, 
  customerAddress, 
  setCustomerAddress, 
  handleSaveCustomer, 
  peopleCount, 
  setPeopleCount,
  showPeopleInput, 
  setShowPeopleInput,
  setShowCartView 
}) => {
  const [isExistingCustomer, setIsExistingCustomer] = useState(false);

  const saveCustomerToBackend = async (name, phone, address) => {
    try {
      const response = await fetch("http://localhost:5000/api/customers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, phone, address }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Failed to save customer");
      return data;
    } catch (err) {
      console.error("Error saving customer:", err);
      throw err;
    }
  };

  const fetchCustomerByMobile = debounce(async (mobile) => {
    try {
      if (!mobile.trim()) return;
      const res = await fetch(`http://localhost:5000/api/customers/by-phone?phone=${encodeURIComponent(mobile)}`);
      const customer = await res.json();
  
      if (customer && customer.name) {
        setCustomerName(customer.name || "");
        setCustomerAddress(customer.address || "");
        setIsExistingCustomer(true);
      } else {
        setCustomerName("");
        setCustomerAddress("");
        setIsExistingCustomer(false);
      }
    } catch (error) {
      console.error("Customer fetch error:", error);
    }
  }, 300);

  const toggleCustomerForm = () => {
    const newState = !showCustomerForm;
    setShowCustomerForm(newState);
    setShowCartView(!newState); // Hide cart when form is shown
    if (showPeopleInput) setShowPeopleInput(false);
  };

  const togglePeopleInput = () => {
    const newState = !showPeopleInput;
    setShowPeopleInput(newState);
    setShowCartView(!newState); // Hide cart when input is shown
    if (showCustomerForm) setShowCustomerForm(false);
  };

  return (
    <div className="border-b border-gray-200 py-2 px-4 flex justify-between items-center gap-2">
      {/* Left: Action Buttons */}
      <div className="flex items-center gap-2">
        {/* Customer Info Button */}
        <div className="relative">
          <button
            className="p-1.5 bg-gray-100 rounded hover:bg-gray-200 border border-gray-300"
            title="Customer Info"
            onClick={toggleCustomerForm}
          >
            <UserRound size={16} className="text-gray-700" />
          </button>

          {showCustomerForm && (
            <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-white border rounded shadow-md p-3 w-64 z-10">
              <label className="text-xs font-medium text-gray-600 mb-1 block">Mobile No</label>
              <input
                type="tel"
                value={customerMobile}
                onChange={(e) => {
                  const value = e.target.value;
                  setCustomerMobile(value);
                  fetchCustomerByMobile(value);
                }}
                className="w-full mb-2 px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none"
              />

              <label className="text-xs font-medium text-gray-600 mb-1 block">Customer Name</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full mb-2 px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none"
              />

              <label className="text-xs font-medium text-gray-600 mb-1 block">Address</label>
              <textarea
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none resize-none"
                rows={2}
              ></textarea>

              <button
                className="mt-3 w-full bg-green-600 text-white text-sm py-1.5 rounded hover:bg-green-700 transition"
                onClick={async () => {
                  try {
                    if (!isExistingCustomer) {
                      await saveCustomerToBackend(customerName, customerMobile, customerAddress);
                      alert("Customer saved successfully");
                    }
                    handleSaveCustomer();
                    setShowCustomerForm(false);
                    setShowCartView(true); // Show cart back after closing
                  } catch (error) {
                    alert("Failed to save customer. Please try again.");
                  }
                }}
              >
                Save
              </button>
            </div>
          )}
        </div>

        <span className="h-5 w-px bg-gray-300" />

        {/* People Count Button */}
        <div className="relative">
          <button
            className={`p-1.5 rounded border ${peopleCount > 0 ? "bg-green-100 border-green-500 text-green-700" : "bg-gray-100 hover:bg-gray-200 border-gray-300"}`}
            onClick={togglePeopleInput}
            title="No. of People"
          >
            <Users size={16} />
          </button>

          {showPeopleInput && (
            <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-white border rounded shadow-md p-2 w-36 z-10">
              <label className="text-xs font-medium mb-1 block text-gray-600">No. of People</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  className="flex-1 border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none"
                  value={peopleCount}
                  onChange={(e) => setPeopleCount(Number(e.target.value))}
                />
                <button
                  className="text-green-600 hover:text-green-800"
                  onClick={() => {
                    setShowPeopleInput(false);
                    setShowCartView(true); // Show cart back after closing
                  }}
                >
                  <CheckCircle size={16} />
                </button>
              </div>
            </div>
          )}
        </div>

        <span className="h-5 w-px bg-gray-300" />

        <button
          className="p-1.5 bg-gray-100 rounded hover:bg-gray-200 border border-gray-300"
          title="Order Instructions"
        >
          <StickyNote size={16} className="text-gray-700" />
        </button>

        <span className="h-5 w-px bg-gray-300" />

        <button className="p-1.5 bg-gray-100 rounded hover:bg-gray-200 border border-gray-300" title="Assign Waiter">
          <ConciergeBell size={16} className="text-gray-700" />
        </button>
      </div>

      <div className="flex items-center gap-1 text-sm text-gray-700">
        <FilePenLine size={16} className="text-gray-600" />
        <span className="font-medium">Order #12345</span>
      </div>
    </div>
  );
};

export default OrderTypeToggle;
