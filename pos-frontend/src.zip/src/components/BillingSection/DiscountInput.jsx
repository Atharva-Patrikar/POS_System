"use client"

import { FaChevronUp, FaChevronDown } from "react-icons/fa"

const DiscountInput = ({showDiscount, setShowDiscount, discountType, setDiscountType, discountValue, setDiscountValue, handleApplyDiscount,
  handleRemoveDiscount}) => {
  return (
    <div className="mb-4">
      <button
        className="flex items-center text-sm font-medium text-black"
        onClick={() => setShowDiscount((prev) => !prev)}
      >
        {showDiscount ? <FaChevronUp className="mr-2" /> : <FaChevronDown className="mr-2" />}
        Apply Discount
      </button>

      {showDiscount && (
        <div className="mt-3 border border-gray-200 rounded-md p-3 bg-white space-y-3">
          <div className="flex space-x-4">
            <label className="flex items-center space-x-1 text-sm">
              <input
                type="radio"
                name="discountType"
                value="percentage"
                checked={discountType === "percentage"}
                onChange={() => setDiscountType("percentage")}
              />
              <span>% Percentage</span>
            </label>
            <label className="flex items-center space-x-1 text-sm">
              <input
                type="radio"
                name="discountType"
                value="amount"
                checked={discountType === "amount"}
                onChange={() => setDiscountType("amount")}
              />
              <span>₹ Amount</span>
            </label>
          </div>

          <div className="flex gap-2">
            <input
              type="number"
              min="0"
              className="w-full border border-gray-300 rounded px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-black"
              placeholder={`Enter discount ${discountType === "percentage" ? "(%)" : "(₹)"}`}
              value={discountValue}
              onChange={(e) => setDiscountValue(e.target.value)}
            />

            {/* ✅ Done Button */}
            <button
              className="bg-green-100 text-green-600 px-3 py-1 rounded hover:bg-green-200 text-sm"
              onClick={handleApplyDiscount}
            >
              Done
            </button>
          </div>

          <button className="text-xs text-red-500 underline" onClick={handleRemoveDiscount}>
            Remove Discount
          </button>
        </div>
      )}
    </div>
  )
}

export default DiscountInput
