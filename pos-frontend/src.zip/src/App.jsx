// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import ItemsPage from "./pages/ItemsPage";
import OrdersPage from "./pages/OrdersPage"; // <-- Import OrdersPage
import './index.css';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Items Page */}
        <Route
          path="/items"
          element={
            <Layout>
              <ItemsPage />
            </Layout>
          }
        />

        {/* Orders Page */}
        <Route
          path="/orders"
          element={
            <Layout>
              <OrdersPage />
            </Layout>
          }
        />

        {/* Default route */}
        <Route
          path="/"
          element={
            <Layout>
              <ItemsPage />
            </Layout>
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
